using MyApp;
using Xunit;

namespace MyTests;

public class MathHelperTests
{
    [Fact]
    public void Add_TwoPositiveNumbers_ReturnsCorrectSum()
    {
        // Arrange
        int a = 2, b = 3;

        // Act
        int result = MathHelper.Add(a, b);

        // Assert
        Assert.Equal(5, result);
    }

    [Fact]
    public void Divide_ReturnsCorrectQuotient()
    {
        double result = MathHelper.Divide(10, 4);
        Assert.Equal(2.5, result, precision: 2);
    }

    [Fact]
    public void Divide_ByZero_ThrowsDivideByZeroException()
    {
        Assert.Throws<DivideByZeroException>(() => MathHelper.Divide(5, 0));
    }
}
