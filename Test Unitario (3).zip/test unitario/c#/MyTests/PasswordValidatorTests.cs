using MyApp;
using Xunit;

namespace MyTests;

public class PasswordValidatorTests
{
    private readonly PasswordValidator _validator = new();

    [Theory]
    [InlineData("Ab1",      false)]   // muy corta
    [InlineData("abcdef12", false)]   // sin mayúscula
    [InlineData("AbcdefGH", false)]   // sin número
    [InlineData("Secret12", true)]    // válida
    public void IsValid_VariousPasswords_ReturnsExpected(string password, bool expected)
    {
        bool result = _validator.IsValid(password);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("Abc12345",        "medium")]
    [InlineData("MyP@ssw0rd!2024", "strong")]
    [InlineData("simple",          "weak")]
    public void GetStrength_ReturnsCorrectLevel(string password, string expectedStrength)
    {
        string strength = _validator.GetStrength(password);
        Assert.Equal(expectedStrength, strength);
    }
}
