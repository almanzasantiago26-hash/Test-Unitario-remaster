using MyApp;
using Xunit;
using Xunit.Abstractions;

namespace MyTests;

public class ProductServiceTests
{
    private readonly ProductService _service = new();
    private readonly ITestOutputHelper _output;

    public ProductServiceTests(ITestOutputHelper output) => _output = output;

    private void SeedProducts()
    {
        _service.AddProduct(new Product(1, "Laptop",  899.99m, 10));
        _service.AddProduct(new Product(2, "Mouse",    19.99m, 50));
        _service.AddProduct(new Product(3, "Monitor", 299.99m,  5));
    }

    [Fact]
    public void AddProduct_InvalidPrice_ThrowsArgumentException()
    {
        var ex = Assert.Throws<ArgumentException>(
            () => _service.AddProduct(new Product(1, "Teclado", -10m, 5))
        );
        Assert.Contains("positivo", ex.Message);
    }

    [Fact]
    public void GetAffordable_ReturnsFilteredAndOrdered()
    {
        SeedProducts();
        var affordable = _service.GetAffordable(300m).ToList();
        _output.WriteLine($"Asequibles encontrados: {affordable.Count}");
        Assert.Equal(2, affordable.Count);
        Assert.Equal("Mouse", affordable[0].Name);
        Assert.All(affordable, p => Assert.True(p.Price <= 300m));
    }

    [Fact]
    public void TryReduceStock_SufficientStock_ReturnsTrueAndReduces()
    {
        SeedProducts();
        bool success = _service.TryReduceStock(2, 3, out string message);
        Assert.True(success);
        Assert.Equal("OK", message);
    }

    [Fact]
    public void TryReduceStock_InsufficientStock_ReturnsFalse()
    {
        SeedProducts();
        bool success = _service.TryReduceStock(3, 100, out string message);
        Assert.False(success);
        Assert.Equal("Stock insuficiente.", message);
    }
}
