using MyApp;
using Moq;
using Xunit;

namespace MyTests;

public class UserServiceTests
{
    private readonly Mock<IUserRepository> _repoMock = new();
    private readonly UserService _service;

    public UserServiceTests()
    {
        _service = new UserService(_repoMock.Object);
    }

    [Fact]
    public async Task RegisterAsync_NewEmail_SavesUserAndReturnsIt()
    {
        _repoMock
            .Setup(r => r.FindByEmailAsync("nuevo@ejemplo.com"))
            .ReturnsAsync((User?)null);

        _repoMock
            .Setup(r => r.SaveAsync(It.IsAny<User>()))
            .Returns(Task.CompletedTask);

        var user = await _service.RegisterAsync("Ana", "nuevo@ejemplo.com", "Secret123");

        Assert.Equal("nuevo@ejemplo.com", user.Email);
        Assert.Equal("user", user.Role);
        _repoMock.Verify(r => r.SaveAsync(It.IsAny<User>()), Times.Once);
    }

    [Fact]
    public async Task RegisterAsync_DuplicateEmail_ThrowsInvalidOperationException()
    {
        _repoMock
            .Setup(r => r.FindByEmailAsync("existente@ejemplo.com"))
            .ReturnsAsync(new User(1, "Otro", "existente@ejemplo.com", "user"));

        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _service.RegisterAsync("Nuevo", "existente@ejemplo.com", "pass")
        );

        _repoMock.Verify(r => r.SaveAsync(It.IsAny<User>()), Times.Never);
    }
}
