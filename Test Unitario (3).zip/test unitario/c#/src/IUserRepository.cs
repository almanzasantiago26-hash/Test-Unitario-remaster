namespace MyApp;

public interface IUserRepository
{
    Task<User?> FindByEmailAsync(string email);
    Task SaveAsync(User user);
}

public record User(int Id, string Name, string Email, string Role);

public class UserService
{
    private readonly IUserRepository _repo;

    public UserService(IUserRepository repo) => _repo = repo;

    public async Task<User> RegisterAsync(string name, string email, string password)
    {
        var existing = await _repo.FindByEmailAsync(email);
        if (existing is not null)
            throw new InvalidOperationException($"El email '{email}' ya está registrado.");

        var user = new User(0, name, email, Role: "user");
        await _repo.SaveAsync(user);
        return user;
    }
}
