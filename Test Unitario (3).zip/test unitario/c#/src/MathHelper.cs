namespace MyApp;

public static class MathHelper
{
    public static int Add(int a, int b) => a + b;

    public static double Divide(double a, double b)
    {
        if (b == 0) throw new DivideByZeroException("No se puede dividir entre cero.");
        return a / b;
    }
}
