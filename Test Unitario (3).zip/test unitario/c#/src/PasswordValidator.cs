using System.Text.RegularExpressions;

namespace MyApp;

public class PasswordValidator
{
    public bool IsValid(string password)
    {
        if (string.IsNullOrEmpty(password) || password.Length < 8) return false;
        if (!Regex.IsMatch(password, "[A-Z]")) return false;
        if (!Regex.IsMatch(password, "[0-9]")) return false;
        return true;
    }

    public string GetStrength(string password)
    {
        if (!IsValid(password)) return "weak";
        if (password.Length >= 12 && Regex.IsMatch(password, "[^a-zA-Z0-9]")) return "strong";
        return "medium";
    }
}
