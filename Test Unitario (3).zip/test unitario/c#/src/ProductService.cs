namespace MyApp;

public record Product(int Id, string Name, decimal Price, int Stock);

public class ProductService
{
    private readonly List<Product> _products = new();

    public void AddProduct(Product product)
    {
        if (product.Price <= 0) throw new ArgumentException("El precio debe ser positivo.");
        if (_products.Any(p => p.Id == product.Id))
            throw new ArgumentException($"Ya existe un producto con Id {product.Id}.");
        _products.Add(product);
    }

    public IEnumerable<Product> GetAffordable(decimal maxPrice) =>
        _products.Where(p => p.Price <= maxPrice).OrderBy(p => p.Price);

    public bool TryReduceStock(int productId, int quantity, out string message)
    {
        var product = _products.FirstOrDefault(p => p.Id == productId);
        if (product is null) { message = "Producto no encontrado."; return false; }
        if (product.Stock < quantity) { message = "Stock insuficiente."; return false; }
        _products[_products.IndexOf(product)] = product with { Stock = product.Stock - quantity };
        message = "OK";
        return true;
    }
}
